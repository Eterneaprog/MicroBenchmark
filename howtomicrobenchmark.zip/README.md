# MicroBenchmark

Tu as besoin d'optimiser tes codes ?
Tu detestes attendre l'éxécution de tes programmes car cela te force à te lever pour aller voir tes collègues à la machine à café ? 
Tu as envie de pouvoir dire à ton RH que le benchmarking, ca n'est pas que du management ? 

Bref : si tu es un humain, 

Ce tutoriel est fait pour toi ! (Quelle chance alors)

Equipe toi maintenant du kit de survie en milieu de complexité et fait tourner tes programmes plus vite que la lumière !

Procédure pour lancer le tutoriel :

- Installe le package howtomicrobenchmark en téléchargeant notre fichier
(Il suffit de mettre le répertoire howtomicrobenchmark en répertoire de travail et de rentrer devtools::install() dans la console)

- Execute les commandes suivantes dans ta console : library("howtomicrobenchmark") 
learnr::run_tutorial("microbenchmark", package = "howtomicrobenchmark")

Bonne chance !